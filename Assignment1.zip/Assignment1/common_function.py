import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import boto3
import pandas as pd
import xlrd
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.functions import col, to_date
from pyspark.context import SparkContext
import logging

def copy_file(bucket_name, source_path, target_path, folder, file):

    s3 = boto3.client('s3')
    s3_resource = boto3.resource('s3')
    copy_source = {
        'Bucket': bucket_name,
        'Key': source_path+folder+file
    }
    
    s3_resource.Object(bucket_name,target_path+folder+file).copy(copy_source)

'''    
def check_ind_file(bucket_name, folder, common_path_inbound, ind_file):
   
    s3 = boto3.client('s3')
    s3_resource = boto3.resource('s3')
    bucket = s3_resource.Bucket(bucket_name) 
    
    objs = list(bucket.objects.filter(Prefix=common_path_inbound+folder+ind_file))
    
    if any([w.key == common_path_inbound+folder+ind_file for w in objs]):
        print("Indicator File Exists for "+ folder + "!")
        return 0
    else :
        print("Indicator File Does not Exists for "+ folder + "!")
        return 1
'''

def convert_xls_to_csv(bucket_name, folder, common_path_pre):

    s3 = boto3.client('s3')
    s3_resource = boto3.resource('s3')
    bucket = s3_resource.Bucket(bucket_name) 
    
    for object_summary in bucket.objects.filter(Prefix=common_path_pre+folder):
        if object_summary.key!=common_path_pre+folder :
            file_nm = object_summary.key.split('/')[-1]
            prefix = object_summary.key.split('.')[1]
            
            if prefix == 'xls' :
                df = pd.read_excel("s3://"+bucket_name +"/"+ common_path_pre + folder + file_nm)
                df.to_csv("s3://"+bucket_name +"/"+ common_path_pre + folder +file_nm.split('.')[0]+'.csv',index=False, sep='|')  
    
def file_metadata_validation(spark, bucket_name, folder, common_path_pre, common_path_inbound, file, delim, header_file, cntr_file, ind_file):

    s3 = boto3.client('s3')
    s3_resource = boto3.resource('s3')
    bucket = s3_resource.Bucket(bucket_name) 
    
    # Header validation Read files
    df = spark.read.format('csv').option('sep',delim).option('header',True).load('s3://'+bucket_name+'/'+common_path_pre+folder+file)

    for obj_hdr in bucket.objects.filter(Prefix=common_path_inbound+folder+header_file):
        key = obj_hdr.key
        header = obj_hdr.get()['Body'].read()
        header = str(header,'UTF-8')

    # Count Validation read files
    for obj_cnt in bucket.objects.filter(Prefix=common_path_inbound+folder+cntr_file):
        key = obj_cnt.key
        cntr = obj_cnt.get()['Body'].read()
        cntr = int(cntr)
        
    # Indicator file validation read
    objs = list(bucket.objects.filter(Prefix=common_path_inbound+folder+ind_file))
    
    if any([w.key == common_path_inbound+folder+ind_file for w in objs]) and ",".join(df.columns)==header and df.count()==cntr:
        print("All validations complete for "+ folder + "!")        
        return True
    else :
        print("Validations failure for "+ folder + "!")
        
        if not any([w.key == common_path_inbound+folder+ind_file for w in objs]):
            print("Indicator file Missing")

        if ",".join(df.columns)!=header:
            print("Header is not matching")
            
        if df.count()!=cnt :
            print("Count is not matching")        
            
        return False
 


def load_to_standard(spark, source_file, target_location, sep, date_format):
    
    df = spark.read.format('csv').option('sep',sep).option('header',True).schema('Script string, Date string, Open float, High float, Low float, Close float, Adj_Close float, Volume float').load(source_file)    
    
    #df=df.withColumnRenamed('Scrip name','Script').withColumnRenamed('Script name','Script').withColumnRenamed('Adj Close','Adj_Close')
    
    df=df.withColumn('Date',to_date(col('Date'),date_format))
    
    df.printSchema()
    df.repartition(col('Script')).write.parquet(target_location)
    
    
def summarize_data(spark, source_file, target_location):
    df=spark.read.parquet(source_file)
    df.createOrReplaceTempView('source_data')
    df=spark.sql("select distinct Script, Week_Num, st_date, End_Date, Open, High, Low, Close, Adj_Close, Volume from (select Script, Week_Num, min(date) over (partition by Year_Week) st_date, max(date) over (partition by Year_Week) as End_Date, first_value(open)  over (partition by Year_Week order by Date) Open, max(high) over (partition by Year_Week) High, min(low) over (partition by Year_Week) Low, last_value(close)  over (partition by Year_Week order by Date) Close, avg(Adj_Close) over (partition by Year_Week) Adj_Close, sum(Volume) over (partition by Year_Week) Volume from ( select Script, 'Week'||extract(week from Date) as Week_Num, extract(year from Date)||'-'||extract(week from Date) as Year_Week,Date, open, high, low, close, adj_close, volume from source_data))")
    #df.show(5)
    df.repartition(1).write.format('csv').option('header',True).save(target_location)        