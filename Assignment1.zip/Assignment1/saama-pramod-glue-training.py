import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import boto3
import pandas as pd
import xlrd
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.functions import col, to_date
from pyspark.context import SparkContext
import logging
import yaml
from common_function import *

## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ['JOB_NAME'])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

s3 = boto3.client('s3')
s3_resource = boto3.resource('s3')

bucket_name = 'cmg-oasis-dev-access-sales-sap'
bucket = s3_resource.Bucket(bucket_name) 

response = s3.get_object(Bucket=bucket_name, Key='oasis_normalized_access/Pramod/Code/config/assignment.yaml')
config = yaml.safe_load(response["Body"])

#print(config['aws.s3.preprocessor_path'])

common_path_inbound=config['aws.s3.inbound_path']
common_path_pre=config['aws.s3.preprocessor_path']
common_path_landing=config['aws.s3.landing_path']
common_path_standard=config['aws.s3.standardized_path']
common_path_out=config['aws.s3.outbound_path']

folder1=config['aws.s3.folder1']
folder2=config['aws.s3.folder2']
file_1=config['aws.s3.file_1']
file_2=config['aws.s3.file_2']
file_1_conv=config['aws.s3.file_1_conv']
file_2_conv=config['aws.s3.file_2_conv']
ind_file=config['aws.s3.ind_file']
cntr_file=config['aws.s3.cntr_file']
header_file=config['aws.s3.header_file']

if __name__ == "__main__":

    
    #Copy files from Inbound to Pre Processed folder 
    copy_file(bucket_name, common_path_inbound, common_path_pre, folder1, file_1)
    convert_xls_to_csv(bucket_name, folder1, common_path_pre)
    
    copy_file(bucket_name, common_path_inbound, common_path_pre, folder2, file_2)
    convert_xls_to_csv(bucket_name, folder2, common_path_pre)
    
    if file_metadata_validation(spark, bucket_name, folder1, common_path_pre, common_path_inbound, file_1_conv, '|', header_file, cntr_file, ind_file) :
        
        copy_file(bucket_name, common_path_pre, common_path_landing, folder1, file_1_conv)
        load_to_standard(spark, 's3://'+bucket_name+'/'+common_path_landing+folder1+file_1_conv,'s3://'+bucket_name+'/'+common_path_standard+folder1,'|','yyyy-mm-dd')
        summarize_data(spark, 's3://'+bucket_name+'/'+common_path_standard+folder1, 's3://'+bucket_name+'/'+common_path_out+folder1)
        
        
    if file_metadata_validation(spark, bucket_name, folder2, common_path_pre, common_path_inbound, file_2_conv, ',', header_file, cntr_file, ind_file):
           
        copy_file(bucket_name, common_path_pre, common_path_landing, folder2, file_2_conv)
        load_to_standard(spark, 's3://'+bucket_name+'/'+common_path_landing+folder2+file_2_conv,'s3://'+bucket_name+'/'+common_path_standard+folder2,',','M/d/yyyy')
        summarize_data(spark, 's3://'+bucket_name+'/'+common_path_standard+folder2, 's3://'+bucket_name+'/'+common_path_out+folder2)

    
    job.commit()